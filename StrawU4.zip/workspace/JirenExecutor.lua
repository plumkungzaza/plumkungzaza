local Key = Enum.KeyCode.Insert

local coregui = game:GetService("CoreGui");
local UserInputService = game:GetService("UserInputService");
if getgenv().Jiren == true then
	coregui:FindFirstChild("Straw"):Destroy()
	getgenv().Jiren = false
end
getgenv().Jiren = true

local TweenService = game:service'TweenService';
--local setthreadcontext = setthreadcontext or syn.set_thread_identity;
function RandomCharacters(length)
	local STR = "";
	for i = 1, length do
		STR = STR .. string.char(math.random(65,90));
	end;
	return STR;
end;

local dragger = {}; 
do
	local players = game:service('Players');
	local player = players.LocalPlayer;
	local mouse = player:GetMouse();
	local run = game:service('RunService');
	local stepped = run.Stepped;
	dragger.new = function(obj)
    	spawn(function()
        	local minitial;
        	local initial;
        	local isdragging;
        	obj.InputBegan:Connect(function(input)
            	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                	isdragging = true;
                	minitial = input.Position;
                	initial = obj.Position;
                	local con;
                	con = stepped:Connect(function()
                    	if isdragging then
                        	local delta = Vector3.new(mouse.X, mouse.Y, 0) - minitial;
                        	obj.Position = UDim2.new(initial.X.Scale, initial.X.Offset + delta.X, initial.Y.Scale, initial.Y.Offset + delta.Y);
                    	else
                        	con:Disconnect();
                    	end;
               	 	end);
                	input.Changed:Connect(function()
                    	if input.UserInputState == Enum.UserInputState.End then
                        	isdragging = false;
                    	end;
                	end);
            	end;
        	end);
    	end)
	end;
end;

----------------------------------------------------------------------------------------------------------------------------------------------------------

local Straw = Instance.new("ScreenGui")
local mainFrame = Instance.new("ImageLabel")
local topbarFrame = Instance.new("ImageLabel")
local JirenLogo = Instance.new("ImageLabel")
local exitBtn = Instance.new("ImageButton")
local exitLabel = Instance.new("TextLabel")
local topbarLabel = Instance.new("TextLabel")
local miniBtn = Instance.new("ImageButton")
local miniLabel = Instance.new("TextLabel")
local scriptsFrame = Instance.new("ImageLabel")
local scriptsScrollingFrame = Instance.new("ScrollingFrame")
local scriptsBox = Instance.new("TextLabel")
local testLabel = Instance.new("TextLabel")
local highlightLabel = Instance.new("TextLabel")
local executeBtn = Instance.new("ImageButton")
local executeLabel = Instance.new("TextLabel")
local clearBtn = Instance.new("ImageButton")
local clearLabel = Instance.new("TextLabel")
local Dragger = Instance.new("ImageButton")
local FakeclearBtn = Instance.new("ImageButton")
local clearLabel_2 = Instance.new("TextLabel")
local FakeexecuteBtn = Instance.new("ImageButton")
local executeLabel_2 = Instance.new("TextLabel")
local ScrollingFrame = Instance.new("ScrollingFrame")
local BGExec = Instance.new("ScrollingFrame")
local Write = Instance.new("TextBox")
local Read = Instance.new("TextLabel")

--Properties:

Straw.Name = "Straw"
Straw.Parent = game:GetService("CoreGui")

mainFrame.Name = "mainFrame"
mainFrame.Parent = Straw
mainFrame.BackgroundColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.BackgroundTransparency = 1.000
mainFrame.BorderSizePixel = 0
mainFrame.ClipsDescendants = true
mainFrame.Position = UDim2.new(0.020999996, 0, 0.0130000012, 0)
mainFrame.Size = UDim2.new(0, 510, 0, 273)
mainFrame.Image = "rbxassetid://3570695787"
mainFrame.ImageColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.ScaleType = Enum.ScaleType.Slice
mainFrame.SliceCenter = Rect.new(100, 100, 100, 100)

topbarFrame.Name = "topbarFrame"
topbarFrame.Parent = mainFrame
topbarFrame.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.BackgroundTransparency = 1.000
topbarFrame.BorderSizePixel = 0
topbarFrame.Size = UDim2.new(1, 0, 0, 28)
topbarFrame.Image = "http://www.roblox.com/asset/?id=1051202035"
topbarFrame.ImageColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.ScaleType = Enum.ScaleType.Slice
topbarFrame.SliceCenter = Rect.new(20, 20, 20, 20)

JirenLogo.Name = "JirenLogo"
JirenLogo.Parent = topbarFrame
JirenLogo.AnchorPoint = Vector2.new(0, 0.5)
JirenLogo.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
JirenLogo.BackgroundTransparency = 1.000
JirenLogo.BorderSizePixel = 0
JirenLogo.Position = UDim2.new(0, 2, 0.5, 0)
JirenLogo.Size = UDim2.new(0, 24, 0, 24)
JirenLogo.ZIndex = 2
JirenLogo.Image = "http://www.roblox.com/asset/?id=4877053590"
JirenLogo.ScaleType = Enum.ScaleType.Fit

exitBtn.Name = "exitBtn"
exitBtn.Parent = topbarFrame
exitBtn.AnchorPoint = Vector2.new(0, 0.5)
exitBtn.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
exitBtn.BackgroundTransparency = 1.000
exitBtn.BorderColor3 = Color3.fromRGB(27, 42, 53)
exitBtn.BorderSizePixel = 0
exitBtn.Position = UDim2.new(1, -25, 0.5, 0)
exitBtn.Size = UDim2.new(0, 19, 0, 19)
exitBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
exitBtn.ImageColor3 = Color3.fromRGB(44, 61, 77)
exitBtn.ImageTransparency = 1.000

exitLabel.Name = "exitLabel"
exitLabel.Parent = exitBtn
exitLabel.AnchorPoint = Vector2.new(0.5, 0.5)
exitLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
exitLabel.BackgroundTransparency = 1.000
exitLabel.BorderSizePixel = 0
exitLabel.Position = UDim2.new(0.5, 0, 0.5, 0)
exitLabel.Size = UDim2.new(0, 25, 0, 25)
exitLabel.Font = Enum.Font.GothamBold
exitLabel.Text = "X"
exitLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
exitLabel.TextSize = 12.000
exitLabel.TextWrapped = true

topbarLabel.Name = "topbarLabel"
topbarLabel.Parent = topbarFrame
topbarLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
topbarLabel.BackgroundTransparency = 1.000
topbarLabel.BorderSizePixel = 0
topbarLabel.Size = UDim2.new(1, 0, 1, 0)
topbarLabel.Font = Enum.Font.SourceSans
topbarLabel.Text = "Strawberry Jam"
topbarLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
topbarLabel.TextSize = 14.000

miniBtn.Name = "miniBtn"
miniBtn.Parent = topbarFrame
miniBtn.AnchorPoint = Vector2.new(0, 0.5)
miniBtn.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
miniBtn.BackgroundTransparency = 1.000
miniBtn.BorderColor3 = Color3.fromRGB(27, 42, 53)
miniBtn.BorderSizePixel = 0
miniBtn.Position = UDim2.new(1, -50, 0.5, 0)
miniBtn.Size = UDim2.new(0, 19, 0, 19)
miniBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
miniBtn.ImageColor3 = Color3.fromRGB(44, 61, 77)
miniBtn.ImageTransparency = 1.000

miniLabel.Name = "miniLabel"
miniLabel.Parent = miniBtn
miniLabel.AnchorPoint = Vector2.new(0.5, 0.5)
miniLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
miniLabel.BackgroundTransparency = 1.000
miniLabel.BorderSizePixel = 0
miniLabel.Position = UDim2.new(0.5, 0, 0.5, 0)
miniLabel.Size = UDim2.new(0, 25, 0, 25)
miniLabel.Font = Enum.Font.GothamBold
miniLabel.Text = "_"
miniLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
miniLabel.TextSize = 12.000
miniLabel.TextWrapped = true
miniLabel.TextYAlignment = Enum.TextYAlignment.Top

scriptsFrame.Name = "scriptsFrame"
scriptsFrame.Parent = mainFrame
scriptsFrame.Active = true
scriptsFrame.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
scriptsFrame.BackgroundTransparency = 1.000
scriptsFrame.BorderColor3 = Color3.fromRGB(27, 42, 53)
scriptsFrame.BorderSizePixel = 0
scriptsFrame.Position = UDim2.new(0, 10, 0, 35)
scriptsFrame.Selectable = true
scriptsFrame.Size = UDim2.new(1, -20, 1, -71)
scriptsFrame.ZIndex = 2
scriptsFrame.Image = "http://www.roblox.com/asset/?id=3570695787"
scriptsFrame.ImageColor3 = Color3.fromRGB(24, 24, 24)
scriptsFrame.ImageTransparency = 0.250
scriptsFrame.ScaleType = Enum.ScaleType.Slice
scriptsFrame.SliceCenter = Rect.new(100, 100, 100, 100)

scriptsScrollingFrame.Name = "scriptsScrollingFrame"
scriptsScrollingFrame.Parent = scriptsFrame
scriptsScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
scriptsScrollingFrame.BackgroundTransparency = 1.000
scriptsScrollingFrame.BorderSizePixel = 0
scriptsScrollingFrame.Size = UDim2.new(1, 0, 1, 0)
scriptsScrollingFrame.Visible = false
scriptsScrollingFrame.BottomImage = "http://www.roblox.com/asset/?id=2991280711"
scriptsScrollingFrame.CanvasSize = UDim2.new(2, 0, 2, 0)
scriptsScrollingFrame.MidImage = "http://www.roblox.com/asset/?id=2991280711"
scriptsScrollingFrame.ScrollBarThickness = 10
scriptsScrollingFrame.TopImage = "http://www.roblox.com/asset/?id=2991280711"

scriptsBox.Name = "scriptsBox"
scriptsBox.Parent = scriptsScrollingFrame
scriptsBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
scriptsBox.BackgroundTransparency = 1.000
scriptsBox.BorderSizePixel = 0
scriptsBox.Size = UDim2.new(0, 380, 0, 260)
scriptsBox.Font = Enum.Font.Code
scriptsBox.Text = ""
scriptsBox.TextColor3 = Color3.fromRGB(255, 255, 255)
scriptsBox.TextSize = 16.000
scriptsBox.TextXAlignment = Enum.TextXAlignment.Left
scriptsBox.TextYAlignment = Enum.TextYAlignment.Top

testLabel.Name = "testLabel"
testLabel.Parent = scriptsBox
testLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
testLabel.BackgroundTransparency = 1.000
testLabel.BorderSizePixel = 0
testLabel.Size = UDim2.new(1, 0, 1, 0)
testLabel.Font = Enum.Font.Code
testLabel.Text = ""
testLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
testLabel.TextSize = 16.000
testLabel.TextXAlignment = Enum.TextXAlignment.Left
testLabel.TextYAlignment = Enum.TextYAlignment.Top

highlightLabel.Name = "highlightLabel"
highlightLabel.Parent = scriptsBox
highlightLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
highlightLabel.BackgroundTransparency = 1.000
highlightLabel.BorderSizePixel = 0
highlightLabel.Size = UDim2.new(1, 0, 1, 0)
highlightLabel.Font = Enum.Font.Code
highlightLabel.Text = ""
highlightLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
highlightLabel.TextSize = 16.000
highlightLabel.TextXAlignment = Enum.TextXAlignment.Left
highlightLabel.TextYAlignment = Enum.TextYAlignment.Top

executeBtn.Name = "executeBtn"
executeBtn.Parent = mainFrame
executeBtn.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
executeBtn.BackgroundTransparency = 1.000
executeBtn.BorderSizePixel = 0
executeBtn.Position = UDim2.new(0, 10, 1, -30)
executeBtn.Size = UDim2.new(0, 134, 0, 24)
executeBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
executeBtn.ImageColor3 = Color3.fromRGB(93, 188, 210)
executeBtn.ImageTransparency = 1.000
executeBtn.ScaleType = Enum.ScaleType.Slice
executeBtn.SliceCenter = Rect.new(100, 100, 100, 100)

executeLabel.Name = "executeLabel"
executeLabel.Parent = executeBtn
executeLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
executeLabel.BackgroundTransparency = 1.000
executeLabel.BorderSizePixel = 0
executeLabel.Size = UDim2.new(1, 0, 1, 0)
executeLabel.Font = Enum.Font.SourceSans
executeLabel.Text = "Execute"
executeLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
executeLabel.TextSize = 14.000

clearBtn.Name = "clearBtn"
clearBtn.Parent = mainFrame
clearBtn.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
clearBtn.BackgroundTransparency = 1.000
clearBtn.BorderSizePixel = 0
clearBtn.Position = UDim2.new(0, 153, 1, -30)
clearBtn.Size = UDim2.new(0, 124, 0, 24)
clearBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
clearBtn.ImageColor3 = Color3.fromRGB(93, 188, 210)
clearBtn.ImageTransparency = 1.000
clearBtn.ScaleType = Enum.ScaleType.Slice
clearBtn.SliceCenter = Rect.new(100, 100, 100, 100)

clearLabel.Name = "clearLabel"
clearLabel.Parent = clearBtn
clearLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
clearLabel.BackgroundTransparency = 1.000
clearLabel.BorderSizePixel = 0
clearLabel.Size = UDim2.new(1, 0, 1, 0)
clearLabel.Font = Enum.Font.SourceSans
clearLabel.Text = "Clear"
clearLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
clearLabel.TextSize = 14.000

Dragger.Name = "Dragger"
Dragger.Parent = mainFrame
Dragger.Active = false
Dragger.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Dragger.BackgroundTransparency = 1.000
Dragger.Position = UDim2.new(1, -22, 1, -22)
Dragger.Size = UDim2.new(0, 20, 0, 20)
Dragger.Modal = true
Dragger.Image = "rbxassetid://3570695787"
Dragger.ImageColor3 = Color3.fromRGB(24, 24, 24)
Dragger.ScaleType = Enum.ScaleType.Slice
Dragger.SliceCenter = Rect.new(100, 100, 100, 100)

FakeclearBtn.Name = "FakeclearBtn"
FakeclearBtn.Parent = mainFrame
FakeclearBtn.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
FakeclearBtn.BackgroundTransparency = 1.000
FakeclearBtn.BorderSizePixel = 0
FakeclearBtn.Position = UDim2.new(0, 153, 1, -30)
FakeclearBtn.Size = UDim2.new(0, 124, 0, 24)
FakeclearBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
FakeclearBtn.ImageColor3 = Color3.fromRGB(24, 24, 24)
FakeclearBtn.ScaleType = Enum.ScaleType.Slice
FakeclearBtn.SliceCenter = Rect.new(100, 100, 100, 100)

clearLabel_2.Name = "clearLabel"
clearLabel_2.Parent = FakeclearBtn
clearLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
clearLabel_2.BackgroundTransparency = 1.000
clearLabel_2.BorderSizePixel = 0
clearLabel_2.Size = UDim2.new(1, 0, 1, 0)
clearLabel_2.Font = Enum.Font.SourceSans
clearLabel_2.Text = "Clear"
clearLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
clearLabel_2.TextSize = 14.000

FakeexecuteBtn.Name = "FakeexecuteBtn"
FakeexecuteBtn.Parent = mainFrame
FakeexecuteBtn.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
FakeexecuteBtn.BackgroundTransparency = 1.000
FakeexecuteBtn.BorderSizePixel = 0
FakeexecuteBtn.Position = UDim2.new(0, 10, 1, -30)
FakeexecuteBtn.Size = UDim2.new(0, 134, 0, 24)
FakeexecuteBtn.Image = "http://www.roblox.com/asset/?id=3570695787"
FakeexecuteBtn.ImageColor3 = Color3.fromRGB(24, 24, 24)
FakeexecuteBtn.ScaleType = Enum.ScaleType.Slice
FakeexecuteBtn.SliceCenter = Rect.new(100, 100, 100, 100)

executeLabel_2.Name = "executeLabel"
executeLabel_2.Parent = FakeexecuteBtn
executeLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
executeLabel_2.BackgroundTransparency = 1.000
executeLabel_2.BorderSizePixel = 0
executeLabel_2.Size = UDim2.new(1, 0, 1, 0)
executeLabel_2.Font = Enum.Font.SourceSans
executeLabel_2.Text = "Execute"
executeLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
executeLabel_2.TextSize = 14.000

ScrollingFrame.Parent = mainFrame
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BackgroundTransparency = 1.000
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0, 10, 0, 35)
ScrollingFrame.Size = UDim2.new(1, -20, 1, -71)
ScrollingFrame.CanvasSize = UDim2.new(2, 0, 2, 0)
ScrollingFrame.ScrollBarThickness = 10

BGExec.Name = "BGExec"
BGExec.Parent = ScrollingFrame
BGExec.Active = true
BGExec.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
BGExec.BackgroundTransparency = 1.000
BGExec.BorderSizePixel = 0
BGExec.Size = UDim2.new(1, 0, 1, 0)
BGExec.ZIndex = 2
BGExec.CanvasSize = UDim2.new(0, 0, 0, 0)
BGExec.ScrollBarThickness = 0

Write.Name = "Write"
Write.Parent = BGExec
Write.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Write.BackgroundTransparency = 1.000
Write.BorderSizePixel = 0
Write.Size = UDim2.new(1, 0, 1, 0)
Write.ZIndex = 2
Write.ClearTextOnFocus = false
Write.Font = Enum.Font.Code
Write.MultiLine = true
Write.Text = ""
Write.TextColor3 = Color3.fromRGB(204, 204, 204)
Write.TextSize = 14.000
Write.TextStrokeTransparency = 0.950
Write.TextXAlignment = Enum.TextXAlignment.Left
Write.TextYAlignment = Enum.TextYAlignment.Top

Read.Name = "Read"
Read.Parent = BGExec
Read.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Read.BackgroundTransparency = 1.000
Read.BorderSizePixel = 0
Read.ZIndex = 2
Read.Font = Enum.Font.Code
Read.Text = ""
Read.TextColor3 = Color3.fromRGB(204, 204, 204)
Read.TextSize = 14.000
Read.TextStrokeTransparency = 0.950
Read.TextXAlignment = Enum.TextXAlignment.Left
Read.TextYAlignment = Enum.TextYAlignment.Top

----------------------------------------------------------------------------------------------------------------------------------------------------------

local textserv = game:GetService('TextService')
--local screen = ProtoSmasher.bin
--local lua = screen.Bin.Background
--local frame = lua.BGExec
--local read = frame.Read
--local write = frame.Write
--local execbtn = lua.Execute
--local clearbtn = lua.Clear
local localPlayer = game:GetService("Players").LocalPlayer;
local remoteEvent = game:GetObjects("rbxassetid://4543177020")[1];
local remoteFunction = game:GetObjects("rbxassetid://4543178955")[1];
remoteEvent.BackgroundColor3 = Color3.fromRGB(140, 30, 49); 
remoteEvent.AutoButtonColor = false;
remoteFunction.BackgroundColor3 = Color3.fromRGB(140, 30, 49); 
remoteFunction.AutoButtonColor = false;
local tweenService = game:GetService("TweenService");
local players = game:GetService("Players");
local mouse = localPlayer:GetMouse();
local mainFrame = Straw.mainFrame;
------------------------------------
local frame = mainFrame.ScrollingFrame.BGExec
local read = frame.Read
local write = frame.Write
------------------------------------
local topbarFrame = mainFrame.topbarFrame;
local exitBtn = topbarFrame.exitBtn;
local miniBtn = topbarFrame.miniBtn;
local JirenLogo = topbarFrame.JirenLogo;
--local scriptsFrame = mainFrame.scriptsFrame;
--local scriptsScrollingFrame = mainFrame.scriptsScrollingFrame;
--local scriptsBox = scriptsScrollingFrame.scriptsBox;
--local highlightLabel = scriptsBox.highlightLabel;
--local testLabel = scriptsBox.testLabel;
--local remotesFrame = mainFrame.remotesFrame;
--local remotesScrollingFrame = remotesFrame.remotesScrollingFrame;
local executeBtn = mainFrame.FakeexecuteBtn;
local clearBtn = mainFrame.FakeclearBtn;
--local copyRemBtn = mainFrame.copyRemBtn
--local copyScrBtn = mainFrame.copyScrBtn;
local currentButton;
local dlogs, logs = {}, {};
--local syntaxHighlight, transformPath, dumpTable, ValueToReadable;
--local textYSize = scriptsBox.TextSize;
Straw.Parent = coregui;
mainFrame.SliceScale = 0.1
mainFrame.Position = UDim2.new(0.5, -255, 0.5, -136.5)
scriptsFrame.SliceScale = 0.1
executeBtn.SliceScale = 0.1
clearBtn.SliceScale = 0.1
Dragger.SliceScale = 0.05
FakeexecuteBtn.SliceScale = 0.1
FakeexecuteBtn.ImageTransparency = 0.25
FakeclearBtn.SliceScale = 0.1
FakeclearBtn.ImageTransparency = 0.25
exitLabel.Text = "X"
exitLabel.TextSize = 12
exitLabel.Font = Enum.Font.GothamBold

miniLabel.Text = "_"
miniLabel.TextSize = 12
miniLabel.Font = Enum.Font.GothamBold
miniLabel.TextYAlignment = Enum.TextYAlignment.Top

-----------------------------------------------------------------------------------------------------
local function draggable(obj)
	spawn(function()
		local dragging = false;
		local draggableToggle;
		local draggableInput;
		local draggableStart;

		obj.topbarFrame.InputBegan:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseButton1 then
				dragging = true;
				draggableStart = input.Position;
				startPos = obj.AbsolutePosition;
			end;
		end);
		
		obj.topbarFrame.InputEnded:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseButton1 then
				dragging = false;
			end;
		end);
		
		UserInputService.InputChanged:Connect(function(input)
			--[[
			if obj.Parent.Enabled and input.UserInputType == Enum.UserInputType.MouseMovement and dragging then
				local res = obj.Parent.AbsoluteSize;
				obj.Position = UDim2.new(0, startPos.X + (input.Position.X - draggableStart.X), 0, startPos.Y + (input.Position.Y - draggableStart.Y));
			end;
			--]]
			if obj.Parent and input.UserInputType == Enum.UserInputType.MouseMovement and dragging then
				local res = obj.Parent.AbsoluteSize;
				obj.Position = UDim2.new(0, startPos.X + (input.Position.X - draggableStart.X), 0, startPos.Y + (input.Position.Y - draggableStart.Y));
			end;
		end);
	end);
end;

local oldy = mainFrame.AbsoluteSize.Y
local oldwindowdata = {}


do --// UI Setup
	draggable(mainFrame);
	
	local keywords = {
        {["Keyword"] = "print", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "warn", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "FireServer", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "InvokeServer", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "game", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "for", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "and", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "or", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "local", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "if", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "then", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "do", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "while", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "repeat", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "until", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "end", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "function", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "return", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "break", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "else", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "elseif", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "require", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "script", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "loadstring", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "GetService", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "self", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "Ray", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "Color3", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "fromRGB", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "new", ["Color"] = Color3.fromRGB(123, 216, 143)};
        {["Keyword"] = "in", ["Color"] = Color3.fromRGB(252, 97, 141)};
        {["Keyword"] = "(", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = ")", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "{", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "}", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "[", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "]", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "+", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "-", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "*", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "/", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "%", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "^", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "=", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = ",", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "<", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = ">", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = ";", ["Color"] = Color3.fromRGB(252, 97, 141), ["Independent"] = true};
        {["Keyword"] = "true", ["Color"] = Color3.fromRGB(122, 114, 185)};
        {["Keyword"] = "false", ["Color"] = Color3.fromRGB(122, 114, 185)};
        {["Keyword"] = "nil", ["Color"] = Color3.fromRGB(122, 114, 185)};
	};   
	
	local function Resize(part, new, _delay)
		_delay = _delay or 0.5
		local tweenInfo = TweenInfo.new(_delay, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local tween = TweenService:Create(part, tweenInfo, new)
		tween:Play()
	end

    local buttons = {
		["executeBtn"] = function() 
			--[[
            if currentButton then 
                print("Test") 
			end 
			--]]
        end,
		["clearBtn"] = function() 
			--[[
			logs = {}; 
			for i, v in pairs(remotesScrollingFrame:GetChildren()) do 
				if not v:IsA("UIListLayout") then 
					v:Destroy(); 
				end; 
			end; 
			remotesScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0); currentButton = nil; 
			--]]
		end,
		["exitBtn"] = function() 
			currentRemote = nil; 
			getgenv().Jiren = false
			oldy = mainFrame.AbsoluteSize.Y
			Resize(mainFrame, {Size = UDim2.new(0, mainFrame.AbsoluteSize.X, 0, 28)}, 0.25)
			wait(0.12)
			ScrollingFrame.Visible = false
			Dragger.Visible = false
			scriptsFrame.Visible = false
			FakeexecuteBtn.Visible = false
			executeLabel_2.Visible = false
			FakeclearBtn.Visible = false
			clearLabel_2.Visible = false
			executeBtn.Visible = false
			executeLabel.Visible = false
			clearBtn.Visible = false
			clearLabel.Visible = false
			wait(0.12)
			Resize(mainFrame, {Size = UDim2.new(0, 0, 0, 28)}, 0.25)		
			wait(0.25)			
			Straw:Destroy();	
			--mainFrame.Size = UDim2.new(0, 565, 0, 348); 			
		end,
		["miniBtn"] = function()
			if mainFrame.Size ~= UDim2.new(0, mainFrame.AbsoluteSize.X, 0, 28) then
				oldy = mainFrame.AbsoluteSize.Y
				Resize(mainFrame, {Size = UDim2.new(0, mainFrame.AbsoluteSize.X, 0, 28)}, 0.25)
				wait(0.12)
				ScrollingFrame.Visible = false
				Dragger.Visible = false
				scriptsFrame.Visible = false
				FakeexecuteBtn.Visible = false
				executeLabel_2.Visible = false
				FakeclearBtn.Visible = false
				clearLabel_2.Visible = false
				executeBtn.Visible = false
				executeLabel.Visible = false
				clearBtn.Visible = false
				clearLabel.Visible = false
			else
				Resize(mainFrame, {Size = UDim2.new(0, mainFrame.AbsoluteSize.X, 0, oldy)}, 0.25)
				ScrollingFrame.Visible = true
				Dragger.Visible = true
				scriptsFrame.Visible = true
				FakeexecuteBtn.Visible = true
				executeLabel_2.Visible = true
				FakeclearBtn.Visible = true
				clearLabel_2.Visible = true
				executeBtn.Visible = true
				executeLabel.Visible = true
				clearBtn.Visible = true
				clearLabel.Visible = true
			end;
		end
        --["copyRemBtn"] = function() if currentButton then setclipboard(transformPath(logs[currentButton]["Remote"]:GetFullName())); end; end,
        --["copyScrBtn"] = function() if currentButton then setclipboard(transformPath(logs[currentButton]["Calling Script"]:GetFullName())); end; end
    };

    for i, v in pairs(mainFrame:GetDescendants()) do
        if buttons[v.Name] and executeBtn.Visible == true and clearBtn.Visible == true and FakeexecuteBtn.Visible == true and FakeclearBtn.Visible == true then
            v.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseMovement then
                    tweenService:Create(v, TweenInfo.new(0), {ImageTransparency = 0}):Play();
                end;
            end);
            v.InputEnded:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseMovement then
                    tweenService:Create(v, TweenInfo.new(0), {ImageTransparency = 1}):Play();
                end;
            end);
            v.MouseButton1Click:Connect(buttons[v.Name]);
        end;
    end;
end;
-----------------------------------------------------------------------------------------------------

--for i, v in next, {screen, lua, frame, read, write, execbtn, clearbtn} do

--for i, v in next, {mainFrame, frame, read, write, executeBtn, clearBtn} do
	-- // anti pasted detection
	--v.Name = game:GetService("HttpService"):GenerateGUID(false)
--end

local replacements = {['\r'] = '', ['\t'] = '    '}
local keyword_list = {'print', 'warn', 'FireServer', 'InvokeServer', 'game', 'for', 'and', 'or', 'local', 'if', 'then', 'do', 'while', 'repeat', 'until', 'end', 'function', 'return', 'break', 'else', 'elseif', 'require', 'script', 'loadstring', 'GetService', 'self', 'Ray', 'Color3', 'fromRGB', 'new', 'in', '(', ')', '{', '}', '[', ']', '+', '-', '*', '/', '%', '^', '=', ',', '<', '>', ';', 'true', 'false', 'nil'}
local globals_list = {}
local colors = {
	Comment = Color3.fromRGB(32, 96, 32),
	Global = Color3.fromRGB(77, 198, 155),
	Keyword = Color3.fromRGB(86, 156, 214),
	Number = Color3.fromRGB(0, 255, 0),
	String = Color3.fromRGB(224, 112, 112),
	Symbol = Color3.fromRGB(255, 255, 255),
	Word = Color3.fromRGB(255, 255, 255)
}

do
	local env = getfenv(0)

	local function recurse(s, t)
		for i, v in next, t do
			local name = s .. '.' .. i
			globals_list[name] = true
			if type(v) == 'table' then
				recurse(name, v)
			end
		end
	end
	
	setmetatable(globals_list, {
		__index = function(self, what)
			local got = env[what]
			local rl = got ~= nil
			if rl and type(got) == 'table' then
				recurse(what, got)
			end
			self[what] = rl
			return rl
		end
	})
end

local function normalize(t)
	for i = 1, #t do
		t[t[i]] = true
		t[i] = nil
	end
end

normalize(keyword_list)

local function text_size(str, size)
	return textserv:GetTextSize(str, 14, Enum.Font.Code, size)
end

local function cut_off(word, n, t)
	if t == "[" then
		warn(word:sub(n, n))
		warn(word:sub(n + 1, n + 1))
	end
	return word:sub(n, n) == t and word:sub(n + 1, n + 1) == t
end

local function is_long(words, s)
	if words:sub(s, s) == '[' then
		local k = s + 1
		while words:sub(k, k) == '=' do
			k = k + 1
		end
		return words:sub(k, k) == '[', k - s + 1
	end
	return false, 0
end

local function read_long(words, s, n)
	local reached
	for i = s, #words do
		local ch = words:sub(i, i)
		if ch == ']' then
			for j = i + 1, #words do
				local wh = words:sub(j, j)
				if wh ~= '=' then
					if wh == ']' and ((j - i - 1) == n) then
						reached = j
					end
					break
				end
			end
		end
		if reached then
			break
		end
	end
	return (reached or #words) - s + 1
end

local function read_comment(words, s)
	local len = s + 2
	local wlen = #words
	local long, longlen = is_long(words, len)
	if long then
		return read_long(words, len + longlen, longlen - 2) + longlen + 2
	else
		local ch
		repeat
			ch = words:sub(len, len)
			len = len + 1
		until len > wlen or ch == '\n'
		return len - s
	end
end

local function read_string(words, s, q)
	local ret = #words
	local esc = false
	for i = s, ret do
		local c = words:sub(i, i)
		if c == '\\' and not esc then
			esc = true
		elseif c == q and not esc then
			ret = i
			break
		else
			esc = false
		end
	end
	return ret - s + 1
end

local function read_alphanum(words, s)
	local len = 0
	while words:sub(s + len, s + len):match('[%w_.:]') do
		len = len + 1
	end
	return len
end

local function read_symbols(words, s)
	local len = 0
	local word
	repeat
		local nx = s + len
		if cut_off(words, nx, '-') or is_long(words, nx) or cut_off(words, nx+1, "[") then
			break
		end
		word = words:sub(nx, nx)
		len = len + 1
		wait();
	until not word:match('[^%s%w_\'"]')
	return len - 1
end

local function read_whitespace(words, s)
	local len = 0
	while words:sub(s + len, s + len):match('%s') do
		len = len + 1
	end
	return len
end

local function parse_words(words)
	local pos = 1
	local wlen = #words
	local list = {}

	while pos <= wlen do
		local ch = words:sub(pos, pos)
		local frm = read:Clone()
		local col, len

		local long, longlen = is_long(words, pos)

		if long then
			len = read_long(words, pos + longlen, longlen - 2) + longlen
			col = colors.String
		elseif cut_off(words, pos, '-') then
			len = read_comment(words, pos)
			col = colors.Comment
		elseif ch == '"' or ch == '\'' then
			len = read_string(words, pos + 1, ch) + 1
			col = colors.String
		elseif ch:match('[%w_.:]') then
			local word
			len = read_alphanum(words, pos)
			word = words:sub(pos, pos + len - 1)
			if tonumber(word) then
				col = colors.Number
			elseif keyword_list[word] then
				col = colors.Keyword
			else
				local rln = 0
				for cnk in string.gmatch(word, '[^.:]+') do
					local nx = rln + #cnk
					if globals_list[word:sub(1, nx)] then
						rln = nx + 1
					else
						break
					end
				end
				if rln ~= 0 then
					len = rln - 1
					col = colors.Global
				else
					col = colors.Word
				end
			end
		elseif ch:match('[^%s%w_\'"]') then
			len = 1 -- fucking bandaid shit for a crash
			col = colors.Symbol
		elseif ch:match('%s') then
			len = read_whitespace(words, pos)
			col = colors.Word
		else
			error('uwu we did a fucky wucky and the code seems to have failed~!')
		end
		table.insert(list, {
			str = words:sub(pos, pos + len - 1),
			col = col
		})
		pos = pos + len
	end

	return list
end

local function highlight()
	local wtext = write.Text:gsub('[\r\t]', replacements)
	local parsed = parse_words(wtext)
	local x, y = 0, 0
	
	write:ClearAllChildren()
	write.Text = wtext

	local function new_frame(str, col, last, j)
		local txt = str:sub(last, j)
		local sz = text_size(txt, frame.AbsoluteSize)
		local num = (frame.CanvasPosition.Y + frame.AbsoluteSize.Y)
		local num2 = (frame.CanvasPosition.Y - frame.AbsoluteSize.Y)
		
		if (y > num) or (y < num2) then
			--print'what the nig'
			return sz;
		end
		
		if col ~= colors.Word then
			local rd = read:Clone()
			rd.Text = txt
			rd.TextColor3 = col
			rd.Position = UDim2.new(0, x, 0, y)
			rd.Size = UDim2.new(0, sz.X, 0, sz.Y)
			rd.Parent = write
		end

		return sz
	end
	
	
	for i = 1, #parsed do
		local word = parsed[i]
		local str = word.str
		local wl = #str
		local tx = {}
		local last = 1
			
		for j = 1, wl do
			local c = str:sub(j, j)
			if c == '\n' then
				local rd = new_frame(str, word.col, last, j - 1)
				y = y + rd.Y
				x = 0
				last = j + 1
			elseif j == wl then
				local rd = new_frame(str, word.col, last, j)
				x = x + rd.X
			end
		end
	end
end

local function dispatch_job()
	highlight()
end

write:GetPropertyChangedSignal('Text'):Connect(function()
	frame.CanvasSize = UDim2.new(0, write.TextBounds.X, 0, write.TextBounds.Y)
	coroutine.wrap(dispatch_job)()
end)

coroutine.resume(coroutine.create(function()
	local size = frame.CanvasPosition;
	local floor = math.floor;
	local wait = wait;
	while wait(1) do
		local new = frame.CanvasPosition
		local vec1 = Vector2.new(size.X, size.Y)
		local vec2 = Vector2.new(new.X, new.Y)
		local distance = floor((vec1 - vec2).magnitude)
		
		if distance > 0 then
			coroutine.wrap(dispatch_job)()
		end
		
		size = new;
	end
end))

executeBtn.MouseButton1Click:connect(function()
	local chunk = string.sub(string.lower(game:GetService("HttpService"):GenerateGUID(false)), 1, 8)
	local results = {loadstring(write.Text, ("[%s]"):format(chunk))}

	if (not results[1]) then
		warn("[" .. chunk .. "] Syntax Error: " .. tostring(results[2]) .. ".")
		return;
	end

	spawn(results[1])
end)

clearBtn.MouseButton1Click:Connect(function()
	write:ClearAllChildren()
	write.Text = ''
end)

do
	local UserInputService = game:GetService("UserInputService")
	local gui2 = mainFrame.Dragger;
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	local offset
	
	local function update(input)
		local delta = input.Position - dragStart
		gui2.Position = UDim2.new(0, startPos.X + delta.X, 0, startPos.Y + delta.Y)
	end
	
	gui2.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui2.AbsolutePosition
			
			local mouse = UserInputService:GetMouseLocation()
			mouse = Vector2.new(mouse.X, mouse.Y - 36);
			offset = (startPos - mouse);
			
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
					coroutine.wrap(highlight)()
				end
			end)
		end
	end)
	
	gui2.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	UserInputService.InputChanged:Connect(function(input)
		if input == dragInput and dragging then
			update(input)
		end
	end)
	
	UserInputService.InputBegan:Connect(function(input)
		if input.KeyCode == Key then
			mainFrame.Visible = not mainFrame.Visible;
		end
	end)

	local sizing = false;
	local function resize()
		local obj = gui2
		local obj2 = mainFrame
		
		local mouse = UserInputService:GetMouseLocation()
		mouse = Vector2.new(mouse.X, mouse.Y - 36);
		
		local x = mouse.X - obj2.AbsolutePosition.X - offset.X
		local y = mouse.Y - obj2.AbsolutePosition.Y - offset.Y
		
		if x < 510 then
			x = 510
		end
		
		if y < 273 then
			y = 273
		end
		obj2.Size = UDim2.new(0, x, 0, y)
		obj.Position = UDim2.new(1, -22, 1, -22)
	end
	
	gui2:GetPropertyChangedSignal("Position"):connect(resize)
end