local Key = "L" 
local f = Enum.KeyCode[Key]
local UI = loadstring(game:HttpGet("https://pastebin.com/raw/LjjKSWei"))()
local Window = UI.new(false)
Window.ChangeToggleKey(f)
local ScriptCategory1 = Window:Category("Scripts 1")
local ScriptCategory2 = Window:Category("Scripts 2")
local ScriptCategory3 = Window:Category("Scripts 3")
local ScriptCategory4 = Window:Category("Scripts 4")
local ScriptCategory5 = Window:Category("Scripts 5")
local Utils = Window:Category("Utils")
local CreditsCategory = Window:Category("Credits")

local VisualsItemESP = ScriptCategory1:Sector("This script work on most games")
local Stats = ScriptCategory1:Sector("")
local Utilss = Utils:Sector("Utils")

_G.TpItem = false;
VisualsItemESP:Cheat(
	"Checkbox", 
	"Bring Item", 
	function(State)  
	  _G.TpItem = not _G.TpItem
	  while _G.TpItem do
	  wait()
		for i,x in ipairs(game.workspace:GetChildren()) do
          if x:IsA("Tool") then
          local tweens  = game:GetService("TweenService")
          local info = TweenInfo.new(0)
          local phum = x.Handle
          phum.Anchored = true
          local move = tweens:Create(phum,info,{CFrame = game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame})
          move:Play()
          wait()
          phum.Anchored = false
        end
      end
    end
	end
)

ESPEnabled = false
ESPLength  = 1000000

local plr = game:GetService("Players").LocalPlayer
local char = plr.Character
local root = char.HumanoidRootPart
local Plrs = game:GetService("Players")
local MyPlr = Plrs.LocalPlayer
local MyChar = MyPlr.Character
local CoreGui = game:GetService("CoreGui")
local Run = game:GetService("RunService")

CharAddedEvent = { }

Plrs.PlayerAdded:connect(function(plr)
   if CharAddedEvent[plr.Name] == nil then
       CharAddedEvent[plr.Name] = plr.CharacterAdded:connect(function(char)
           if ESPEnabled then
               RemoveESP(plr)
               CreateESP(plr)
           end
       end)
   end
end)

Plrs.PlayerRemoving:connect(function(plr)
   if CharAddedEvent[plr.Name] ~= nil then
       CharAddedEvent[plr.Name]:Disconnect()
       CharAddedEvent[plr.Name] = nil
   end
   RemoveESP(plr)
end)

function UpdateESP(plr)
   local Find = CoreGui:FindFirstChild("ESP_" .. plr.Name)
Find.Frame.Names.TextColor3 = Color3.new(0.8, 0.8, 0)
Find.Frame.Names.TextColor3 = Color3.new(1, 1, 1)
Find.Frame.Dist.TextColor3  = Color3.new(1, 1, 1)
local GetChar               = plr.Character
       if MyChar and GetChar then
           local Find2 = MyChar:FindFirstChild("HumanoidRootPart")
           local Find3 = GetChar:FindFirstChild("HumanoidRootPart")
           local Find4 = GetChar:FindFirstChildOfClass("Humanoid")
           if Find2 and Find3 then
               local pos = Find3.Position
               local Dist = (Find2.Position - pos).magnitude
               if Dist > ESPLength then
                   Find.Frame.Names.Visible = false
                   Find.Frame.Dist.Visible = false
                   return
               else
                   Find.Frame.Names.Visible = true
                   Find.Frame.Dist.Visible = true
               end
               Find.Frame.Dist.Text = "Distance: " .. string.format("%.0f", Dist)  
       end
   end
end

function RemoveESP(plr)
   local ESP = CoreGui:FindFirstChild("ESP_" .. plr.Name)
   if ESP then
       ESP:Destroy()
   end
end

function CreateESP(plr)
   if plr ~= nil then
       local GetChar = plr.Character
       if not GetChar then return end
       local GetHead do
           repeat wait() until GetChar:FindFirstChild("Head")
       end
       GetHead = GetChar.Head
       
       local bb = Instance.new("BillboardGui", CoreGui)
       bb.Adornee = GetHead
       bb.ExtentsOffset = Vector3.new(0, 1, 0)
       bb.AlwaysOnTop = true
       bb.Size = UDim2.new(0, 5, 0, 5)
       bb.StudsOffset = Vector3.new(0, 3, 0)
       bb.Name = "ESP_" .. plr.Name
       
       local frame = Instance.new("Frame", bb)
       frame.ZIndex = 10
       frame.BackgroundTransparency = 1
       frame.Size = UDim2.new(1, 0, 1, 0)
       
       local TxtName = Instance.new("TextLabel", frame)
       TxtName.Name = "Names"
       TxtName.ZIndex = 10
       TxtName.Text = plr.Name
       TxtName.BackgroundTransparency = 1
       TxtName.Position = UDim2.new(0, 0, 0, -45)
       TxtName.Size = UDim2.new(1, 0, 10, 0)
       TxtName.Font = "SourceSansBold"
       TxtName.TextColor3 = Color3.new(255, 255, 255)
       TxtName.TextSize = 14
       TxtName.TextStrokeTransparency = 0.5
       
       local TxtDist = Instance.new("TextLabel", frame)
       TxtDist.Name = "Dist"
       TxtDist.ZIndex = 10
       TxtDist.Text = ""
       TxtDist.BackgroundTransparency = 1
       TxtDist.Position = UDim2.new(0, 0, 0, -35)
       TxtDist.Size = UDim2.new(1, 0, 10, 0)
       TxtDist.Font = "SourceSansBold"
       TxtDist.TextColor3 = Color3.new(255, 255, 255)
       TxtDist.TextSize = 15
       TxtDist.TextStrokeTransparency = 0.5
   end
end


Run:BindToRenderStep("UpdateESP", Enum.RenderPriority.Character.Value, function()
   for _, v in next, Plrs:GetPlayers() do
       UpdateESP(v)
   end
end)

VisualsItemESP:Cheat(
	"Checkbox", -- Type
	"ESP", -- Name
	function(State) -- Callback function	  
	  ESPEnabled = not ESPEnabled
   if ESPEnabled then
       for _, v in next, Plrs:GetPlayers() do
           if v ~= MyPlr then
               if CharAddedEvent[v.Name] == nil then
                   CharAddedEvent[v.Name] = v.CharacterAdded:connect(function(Char)
                       if ESPEnabled then
                           RemoveESP(v)
                           CreateESP(v)
                       end
                       repeat wait() until Char:FindFirstChild("HumanoidRootPart")
                   end)
               end
               RemoveESP(v)
               CreateESP(v)
           end
       end
   else
       for _, v in next, Plrs:GetPlayers() do
           RemoveESP(v)
       end
   end
	end
)

Utilss:Cheat("onlybutton", "", function()
game.CoreGui.SerialLibrary:Destroy()
end, {
  text = "Destroy"
})


Stats:Cheat("Label", "xxxxxxx", function()
end
)

Stats:Cheat("Label", "", function()
end
)

AimbotKey = ""

VisualsItemESP:Cheat("Textbox", "Aimbot Key", function(Value)
  local input = Value
  AimbotKey = input
end, {
  placeholder = ""
})

SpeedBox = ""

VisualsItemESP:Cheat("Textbox", "Speed Key", function(Value)
  local input = Value
  SpeedBox = input
end, {
  placeholder = ""
})

PName1 = ""

VisualsItemESP:Cheat("Textbox", "Player Name", function(Value)
  local input = Value
  PName1 = input
end, {
  placeholder = ""
})

PName2 = ""

VisualsItemESP:Cheat("Textbox", "Player Name", function(Value)
  local input = Value
  PName2 = input
end, {
  placeholder = ""
})

GCC = ""

VisualsItemESP:Cheat("onlybutton", "", function()
  GCC = tostring(game.Players.LocalPlayer.Character.HumanoidRootPart.Position)
  local y = game:GetService("CoreGui").SerialLibrary.Container.Categories["Scripts 1"].R[""].Container["Location"].Title
  y.Text = GCC
  y.TextColor3 = Color3.new(0,255,0)
  end, {
    text = "Get Location"
})

VisualsItemESP:Cheat("onlybutton", "", function()
local Plr = game:GetService("Players").LocalPlayer
local Mouse = Plr:GetMouse()
Mouse.Button1Down:connect(function()
if not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.LeftControl) then return end
if not Mouse.Target then return end
Plr.Character:MoveTo(Mouse.Hit.p)
end)
  end, {
    text = "Teleport (Ctrl+Click)"
})

Stats:Cheat("onlybutton", "", function()
	local Player = game.Players.LocalPlayer
local Mouse = Player:GetMouse()
local CurrentCamera = game.Workspace.CurrentCamera
local Enabled = false
local PlayerGetMouse = game:GetService("Players").LocalPlayer:GetMouse()

function GetNearestPlayerToMouse()
local players = {}
local plrhld = {}
local dists = {}
for i, v in pairs(game.Players:GetPlayers()) do
if v~=Player then
table.insert(players,v)
end
end
for i, v in pairs(players) do
if v and (v.Character)~=nil then
local head = v.Character:FindFirstChild("Head")
if head~=nil then
local dist = (head.Position-game.Workspace.CurrentCamera.CoordinateFrame.p).magnitude
plrhld[v.Name..i]={}
plrhld[v.Name..i].dist=dist
plrhld[v.Name..i].plr=v
local ray = Ray.new(game.Workspace.CurrentCamera.CoordinateFrame.p,(Mouse.Hit.p-game.Workspace.CurrentCamera.CoordinateFrame.p).unit*dist)
local hit,pos = game.Workspace:FindPartOnRay(ray,game.Workspace)
local diff = math.floor((pos-head.Position).magnitude)
plrhld[v.Name..i].diff=diff
table.insert(dists,diff)
end
end
end
if unpack(dists) == nil then
return false
end
local ldist = math.floor(math.min(unpack(dists)))
if ldist > 100 then
return false
end
for i, v in pairs(plrhld) do
if v.diff==ldist then
return v.plr
end
end
return false
end

PlayerGetMouse.KeyDown:connect(function(key)
if key == AimbotKey then
Enabled = true
end
end)

PlayerGetMouse.KeyUp:connect(function(key)
if key == AimbotKey then
Enabled = false
end
end)

game:GetService("RunService").RenderStepped:connect(
function()
if Enabled then
local Target = GetNearestPlayerToMouse()
if (Target~=false) then
local head = Target.Character:FindFirstChild("Head")
if head then
game.Workspace.CurrentCamera.CoordinateFrame = CFrame.new(game.Workspace.CurrentCamera.CoordinateFrame.p,head.CFrame.p)
end
end
end
end)
  end, {
    text = "Aimbot"
})

local plr = game:GetService("Players").LocalPlayer
local char = plr.Character
local mouse = game:GetService("Players").LocalPlayer:GetMouse()
local hum = char:FindFirstChild("HumanoidRootPart")

Stats:Cheat("onlybutton", "   Speed", function()

  local plr = game:GetService("Players").LocalPlayer
    local char = plr.Character
    local mouse = game:GetService("Players").LocalPlayer:GetMouse()
    local hum = char:FindFirstChild("HumanoidRootPart")
    mouse.KeyDown:connect(function(key)
    if key == SpeedBox then
        loop = true
            while loop do
                hum.CFrame = hum.CFrame + hum.CFrame.lookVector * 3
            wait()
          end
        end
      end)
    end)    
    mouse.KeyUp:connect(function(key)
    if key == SpeedBox then
      loop = false
    end     

  end, {
    text = "Speed"
})

local Spy = false
function GetPlayer(String) 
    local Found = {}
    local strl = String:lower()
    if strl == "all" then
        for i,v in pairs(game.Players:GetPlayers()) do
            table.insert(Found,v)
        end
    elseif strl == "others" then
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name ~= game.Players.LocalPlayer.Name then
                table.insert(Found,v)
            end
        end    
    else
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name:lower():sub(1, #String) == String:lower() then
                table.insert(Found,v)
            end
        end    
    end
    return Found    
end

Stats:Cheat("onlybutton", "", function()
  Spy = not Spy
	for i,v in pairs(GetPlayer(PName1)) do
		if Spy then
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
		else
		lplayer = game:GetService("Players").LocalPlayer
            if lplayer.Character.Humanoid then
            game:GetService("Workspace").CurrentCamera.CameraSubject = lplayer.Character.Humanoid
            else
            game:GetService("Workspace").CurrentCamera.CameraSubject = lplayer.Character.Head
            end	 
		end
	end
  end, {
    text = "View"
})

Stats:Cheat("onlybutton", "", function()
	for i,v in pairs(GetPlayer(PName2)) do
    lplayer.Character.HumanoidRootPart.CFrame = game:GetService("Players")[v.Name].Character.HumanoidRootPart.CFrame
  end
  end, {
    text = "Teleport"
})

Stats:Cheat("Label", "Location", function()
end
)

Stats:Cheat("onlybutton", "", function()
	setclipboard(GCC)
  end, {
    text = "Copy location"
})

local Credits = CreditsCategory:Sector("Special Thanks")
local Tester = CreditsCategory:Sector("Testers")
Credits:Cheat("Label", "ProSploitDev#0001 - Creator")
Tester:Cheat("Label", "[Jiren] huge_0013#6320 - Tester")
function tp()
for i,x in ipairs(game.workspace:GetChildren()) do
if x:IsA("Tool") then
local tweens  = game:GetService("TweenService")
local info = TweenInfo.new(0)
local phum = x.Handle
phum.Anchored = true
local move = tweens:Create(phum,info,{CFrame = game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame})
move:Play()
wait()
phum.Anchored = false
end
end
end

while wait() do
for i,x in ipairs(game.workspace:GetChildren()) do
-------------------------------------------------------------------------------------------------------------------
local t = game:GetService("CoreGui").SerialLibrary.Container.Categories["Scripts 1"].R[""].Container["xxxxxxx"].Title
if x:IsA("Tool") then
t.Text = "Found"
t.TextColor3 = Color3.new(0,255,0)
else
t.Text = "Not Found"
t.TextColor3 = Color3.new(255,0,0)
end
-------------------------------------------------------------------------------------------------------------------
local j = game:GetService("CoreGui").SerialLibrary.Container.Categories["Scripts 1"].R[""].Container[""].Title
if ESPEnabled == true then
j.Text = "Enabled"
j.TextColor3 = Color3.new(0,255,0)
else
j.Text = "Disabled"
j.TextColor3 = Color3.new(255,0,0)
end
-------------------------------------------------------------------------------------------------------------------
end
end